#ifndef QTIPCSERVER_H
#define QTIPCSERVER_H

// Define CommandCoin-Qt message queue name
#define BITCOINURI_QUEUE_NAME "CommandCoinURI"

void ipcScanRelay(int argc, char *argv[]);
void ipcInit(int argc, char *argv[]);

#endif // QTIPCSERVER_H
